import { useState, useRef } from "react";
import axios from "axios";
import NavBar from "./NavBar";
import "./App.css";

export default function Create() {
    const rRno = useRef();
    const rName = useRef();
    const rMarks = useRef();

    const [rno, setRno] = useState("");
    const [name, setName] = useState("");
    const [marks, setMarks] = useState("");
    const [file, setFile] = useState(null);  // Initialize file as null
    const [msg, setMsg] = useState("");

    const hRno = (event) => { setRno(event.target.value); }
    const hName = (event) => { setName(event.target.value); }
    const hMarks = (event) => { setMarks(event.target.value); }
    const hFile = (event) => { setFile(event.target.files[0]); }

    const save = (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append("rno", rno);
        formData.append("name", name);
        formData.append("marks", marks);
        formData.append("file", file);

        let url = "http://localhost:9000/save";
        axios.post(url, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(res => {
                if (res.data.insertedId === rno) {
                    setMsg("Record saved successfully");
                    setRno("");
                    setName("");
                    setMarks("");
                    setFile(null);  // Reset file input
                    rRno.current.focus();
                } else {
                    setMsg("Record saved");
                    setRno("");
                    rRno.current.focus();
                }
            })
            .catch(err => setMsg("Issue: " + err));
    }

    return (
        <>
            <NavBar />
            <center>
            <h1 className="heading">Create Records Page</h1>
                <form onSubmit={save}>
                    <input type="number" placeholder="Enter roll no" onChange={hRno} ref={rRno} value={rno} />
                    <br /><br />
                    <input type="text" placeholder="Enter name" onChange={hName} ref={rName} value={name} />
                    <br /><br />
                    <input type="number" placeholder="Enter marks" onChange={hMarks} ref={rMarks} value={marks} />
                    <br /><br />
                    <input type="file" placeholder="Choose file" onChange={hFile} />
                    <br /><br />
                    <button type="submit">Save</button>
                    <br /><br />
                </form>
                <h2>{msg}</h2>
            </center>
        </>
    );
}
