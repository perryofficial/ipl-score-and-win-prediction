import { useState, useEffect } from "react";
import axios from "axios";
import NavBar from "./NavBar";
import "./App.css";
import {useNavigate} from "react-router-dom";
import { saveAs } from "file-saver";

export default function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    let url = "http://localhost:9000/gs";
    axios.get(url)
      .then(res => setData(res.data))
      .catch(err => alert("issue " + err));
  }, []);

  const download = (image) => {
    let url = "http://localhost:9000/uploads/"+image;
    saveAs(url, download);
  }

  const delStu = (rno,image) => {
    // let d = { data: { rno } };
    let url = "http://localhost:9000/rs";
    let da = { data:{rno,image}};
    axios.delete(url, da)
      .then(res => {
        alert("deleted");
        window.location.reload();
      })
      .catch(err => alert("issue " + err));
  }

  const nav = useNavigate();
  const updateStu = (rno,name,marks) => {
    nav("/update", {state:{rno,name,marks}});
  }

  

  

  return (
    <>
      <NavBar />
      <h1 className="heading">Student Management System</h1>
      <center>
        <h1>Home Page</h1>
        <table border="5" style={{ width: "80%" }}>
          <thead>
            <tr>
              <th>Roll No</th>
              <th>Name</th>
              <th>Marks</th>
              <th>Image</th>
              <th>Delete</th>
              <th>Update</th>
              <th>Download</th>
              
            </tr>
          </thead>
          <tbody>
            {data.map(e => (
              <tr key={e._id} style={{ textAlign: "center" }}>
                <td>{e._id}</td>
                <td>{e.name}</td>
                <td>{e.marks}</td>
                <td><img src={"http://localhost:9000/uploads/"+e.image}height={100} width={100}></img></td>

                <td>
                  <button onClick={() => { if (window.confirm("Are you sure?")) delStu(e._id) }}>
                    Delete
                  </button>
                </td>
                <td>
                  <button onClick={() => {  updateStu(e._id,e.name,e.marks) }}>
                    Update
                  </button>
                </td>
                <td>
                  <button onClick={() => {  download(e.image) }}>
                    Download
                  </button>
                </td>
              </tr>
              
            ))}
            
          </tbody>
        </table>
      </center>
    </>
  );
}
