import { useState, useRef, useEffect } from "react";
import axios from "axios";
import NavBar from "./NavBar";
import { useLocation, useNavigate } from "react-router-dom";
import "./App.css";

export default function Update() {
  const rRno = useRef();
  const rName = useRef();
  const rMarks = useRef();

  const [rno, setRno] = useState("");
  const [name, setName] = useState("");
  const [marks, setMarks] = useState("");
  const [msg, setMsg] = useState("");

  const hRno = (event) => { setRno(event.target.value); }
  const hName = (event) => { setName(event.target.value); }
  const hMarks = (event) => { setMarks(event.target.value); }

  const loc = useLocation();

  useEffect(() => {
    if (loc.state) {
      setRno(loc.state.rno || "");
      setName(loc.state.name || "");
      setMarks(loc.state.marks || "");
    }
  }, [loc.state]);

  const nav = useNavigate();

  const save = (event) => {
    event.preventDefault();
    let data = { rno, name, marks };
    let url = "http://localhost:9000/us"; // Ensure this matches your backend route
    axios.put(url, data) // Use axios.put for updating if the backend is set for PUT
        .then(res => {
            alert("Record Updated");
            nav("/");
        })
        .catch(err => setMsg("Issue: " + err));
}

  return (
    <>
      <NavBar />
      <center>
      <h1 className="heading">Update Records Page</h1>
        <form onSubmit={save}>
          <input type="number" placeholder="Enter roll no" onChange={hRno} ref={rRno} value={rno} disabled />
          <br /><br />
          <input type="text" placeholder="Enter name" onChange={hName} ref={rName} value={name} />
          <br /><br />
          <input type="number" placeholder="Enter marks" onChange={hMarks} ref={rMarks} value={marks} />
          <br /><br />
          <button type="submit">Save</button>
          <br /><br />
        </form>
        <h2>{msg}</h2>
      </center>
    </>
  );
}
